<!--
 * @Author: lpj 1248708823@qq.com
 * @Date: 2022-09-06 09:51:14
 * @LastEditors: lpj 1248708823@qq.com
 * @LastEditTime: 2022-09-06 10:17:26
 * @FilePath: \gok-portal\src\views\home\index.vue
 * @Description: 主页
-->
<template>
 <div>
  我是主页
 </div>
</template>
<script>
 export default {
   data () {
     return {
 
     }
   },
   computed:{
 
   },
   methods:{
 
   },
   components: {
 
   },
 }
</script>
<style lang='less' scoped>
 
</style>

