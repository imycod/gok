<!--
 * @Author: lpj 1248708823@qq.com
 * @Date: 2022-09-06 09:41:05
 * @LastEditors: lpj 1248708823@qq.com
 * @LastEditTime: 2022-09-06 09:44:49
 * @FilePath: \gok-portal\src\views\template\layout.vue
 * @Description: 模板外壳布局文件
-->
<template>
 <div>
  <!-- 头部 -->
  我是页面布局文件
  <!-- 差异化配置需要缓存的页面 -->
   <keep-alive>
     <router-view v-if="$route.meta.keepAlive"></router-view>
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive"></router-view>

    <!-- 底部 -->
 </div>
</template>
<script>
 export default {
   data () {
     return {
 
     }
   },
   computed:{
 
   },
   methods:{
 
   },
   components: {
 
   },
 }
</script>
<style lang='less' scoped>
 
</style>
