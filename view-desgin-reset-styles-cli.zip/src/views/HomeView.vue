<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png" />
    <HelloWorld msg="Welcome to Your Vue.js App" />
     <Button type="success">Success</Button>
       <Modal
        :value="true"
        title="Common Modal dialog box title"
        @on-ok="ok"
        @on-cancel="cancel">
        <p>Content of dialog</p>
        <p>Content of dialog</p>
        <p>Content of dialog</p>
    </Modal>

    <div class="view" ></div>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from "@/components/HelloWorld.vue";

export default {
  name: "HomeView",
  components: {
    HelloWorld,
  },
  created() {
    const a = {}
    console.log(a?.b?.c);
  }
};
</script>

<style lang="less" scoped>
 .view   {
  background: @base;
  width: 100px;
  height: 100px;
 }
</style>