<template>
  <div id="app">
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </nav>
    <router-view />
  </div>
</template>

<style lang="less">
#app {
  font-family:-apple-system,BlinkMacSystemFont,Helvetica Neue,PingFang SC,Microsoft YaHei,Source Han Sans SC,Noto Sans CJK SC,WenQuanYi Micro Hei,sans-serif !important;
  //  Mac OS X / macOS 下生效。 auto - 允许浏览器选择字体平滑的优化方式
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
