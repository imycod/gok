/*
 * @Author: lpj 1248708823@qq.com
 * @Date: 2022-09-05 21:32:45
 * @LastEditors: lpj 1248708823@qq.com
 * @LastEditTime: 2022-09-05 21:34:54
 * @FilePath: \gok-portal\src\utils\regex\index.js
 * @Description: 全局分页器
 * 目的： 保证全局设置风格一致。自动进行分页请求。
 */
<template>
  <div></div>
</template>

<script>
export default {

}
</script>

<style>

</style>