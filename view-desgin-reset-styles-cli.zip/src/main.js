import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import loaderIview from "@/utils/loader-IView-component";
import loaderFilters from "@/utils/filters/loader-filters";
import loaderComponents from "@c/loader-components.js";
import loaderDirectives from '@/directives/loader-directives'
import '@design/iview-theme/index.less';
Vue.config.productionTip = false;
// ---------------自动加载脚本区---------------
// 自动加载指令
loaderDirectives(Vue)
// 自动加载iview组件
loaderIview(Vue);
// 自动加载过滤器
loaderFilters(Vue)
// 自动加载全局组件
loaderComponents.install(Vue)
// -------------------------------------------
new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
