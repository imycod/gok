import Vue from "vue";
import VueRouter from "vue-router";
import Layout from "@views/template/layout.vue";
const OnlyRouterView = {
  template: '<router-view />'
}
Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Layout",
    component: Layout,
    redirect: '/home',
    children: [
      // 首页
      {
        path: "home",
        name: "ProtalHome",
        component: () =>
          import("@views/home/index.vue"),
      },

      // 新闻
      {
        path: "news",
        redirect: '/list',
        component:OnlyRouterView,
        children: [
          // 首页
          {
            path: "list",
            name: "NewsList",
            component: () =>
              import("@views/news/list.vue"),
          },
          {
            path: ":id",
            component: () =>
            import("@views/news/detail.vue"),
          },
        ]
      },

      // ---------------校企对接------------------
      // 校企合作
      {
        path: "cooperation",
        component: () =>
        import("@views/cooperation/sp-cooperation/index.vue"),
      },
      // 我要合作
      {
        path: "apply-cooperation",
        component: () =>
        import("@views/cooperation/apply-cooperation/index.vue"),
      },
      // 合作项目展示
      {
        path: "cooperation-product",
        component:OnlyRouterView,
        redirect: '/list',
        children: [
          {
            path: "list",
            component: () =>
              import("@views/cooperation/cooperation-product/list.vue"),
          },
          {
            path: ":id",
            component: () =>
            import("@views/cooperation/cooperation-product/detail.vue"),
          },
        ]
      },

         // 合作课程
        {
          path: "cooperation-course",
          component: () =>
          import("@views/cooperation/cooperation-course/index.vue"),
        },

        // 院校集群
         {
          path: "school",
          component: () =>
          import("@views/cooperation/school/index.vue"),
        },

        // 企业库
        {
          path: "company",
          component: () =>
          import("@views/cooperation/company/index.vue"),
        },
        // ---------------基地介绍------------------
        {
          path: "about",
          component: () =>
          import("@views/about/index.vue"),
        },
    ]
  },
  // 数据大屏
  {
    path: "/data-visual",
    component: () =>
    import("@views/about/index.vue"),
  },
];

const router = new VueRouter({
  routes,
  mode: "history",
});

export default router;
