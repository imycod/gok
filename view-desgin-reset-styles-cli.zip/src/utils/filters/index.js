/*
 * @Author: lpj 1248708823@qq.com
 * @Date: 2022-09-05 21:35:21
 * @LastEditors: lpj 1248708823@qq.com
 * @LastEditTime: 2022-09-05 21:43:27
 * @FilePath: \gok-portal\src\utils\filters\index.js
 * @Description: [全局]过滤器自动注册，太过小众的请放在组件内。自
 */
import DAYJS from 'dayjs'
/**
 * 时间戳转日期格式
 * @param {String} value
 */
export const formatDate = value => {
  return DAYJS(Number(value)).format('YYYY-MM-DD HH:mm')
}