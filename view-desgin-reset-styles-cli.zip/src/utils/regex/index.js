/*
 * @Author: lpj 1248708823@qq.com
 * @Date: 2022-09-05 21:32:45
 * @LastEditors: lpj 1248708823@qq.com
 * @LastEditTime: 2022-09-05 21:34:54
 * @FilePath: \gok-portal\src\utils\regex\index.js
 * @Description: 全局正则表达式
 */
//  手机号（宽松判断，以防后面还要修改）
export const specialPhoneFormat = /^1\d{10}$/;