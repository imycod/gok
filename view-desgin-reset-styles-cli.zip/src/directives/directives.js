/*
 * @Author: lpj 1248708823@qq.com
 * @Date: 2022-09-05 22:19:27
 * @LastEditors: lpj 1248708823@qq.com
 * @LastEditTime: 2022-09-05 22:20:56
 * @FilePath: \gok-portal\src\directives\directives.js
 * @Description: 导入指令文件
 */
import imageErr from './modules/image-err' // 图片加载出错时的处理
const directives = {
  imageErr
}

export default directives
