const { defineConfig } = require("@vue/cli-service");
const path = require('path')
module.exports = defineConfig({
  transpileDependencies: true,
  // eslint報錯能不能啓動
  lintOnSave: false,
  outputDir: 'dist', // 输出文件目录
  assetsDir: 'static', // 放置生成的静态资源文件
  filenameHashing: true, // 文件名HASH值
  lintOnSave: process.env.NODE_ENV !== 'production',// eslint-loader 
  productionSourceMap: false, // 生产环境的source map，生产环境下不开启以优化项目
 // css相关配置
  css: {
    sourceMap: true, // 开启 CSS source maps?
    loaderOptions:{
      less:{
        lessOptions:{
          javascriptEnabled: true,
        }
      }
    }
  },
  
  configureWebpack: { 
    resolve: {
      // 配置路径别名 
      // ！！！ 这边配置完也要去jsconfig配置下，智能提示
      alias: {
        '@': path.resolve(__dirname, './src'),
        '@views': path.resolve(__dirname, './src/views'),
        '@c': path.resolve(__dirname, './src/components'),
        '@router': path.resolve(__dirname, './src/router'),
        '@store': path.resolve(__dirname, './src/store'),
        '@utils': path.resolve(__dirname, './src/utils'),
        '@images': path.resolve(__dirname, './src/assets/images'),
        '@design': path.resolve(__dirname, './src/assets/design'),
        '@enum': path.resolve(__dirname, './src/enum'),
      },
    },
  },
    //  less的配置 主要是为了用到全局变量
    chainWebpack: config => {
      const types = ['vue-modules', 'vue', 'normal-modules', 'normal']
      types.forEach(type => addStyleResource(config.module.rule('less').oneOf(type)))
    },
});

function addStyleResource (rule) {
  rule.use('style-resource')
    .loader('style-resources-loader')
    .options({
      patterns: [
        path.resolve(__dirname, './src/assets/design/gok/index.less'),
      ],
    })
}