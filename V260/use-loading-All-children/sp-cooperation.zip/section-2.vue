<template>
  <div class="container flex-colum" v-if="list.length">
    <div class="content ">
      <div v-scrollReveal>
        <div class="title">校企合作业务服务流程</div>
        <p class="sub">School-enterprise cooperation achievements case</p>
      </div>
      <div class="swiper-container3 ">
        <div class="swiper-wrapper tarans ">
          <div class="swiper-slide cp hvr-shadow" v-for="(item,index) in list" :key="index">
            <div class="number">{{ index + 1 }}</div>
            <div v-for="(citem,cindex) in item.tags" :key="cindex">
              <span class="tag">{{ citem }}</span>
              <br>
            </div>
            <div class="big-number">{{ index + 1 }}</div>
            <div class="ivu-dividers"></div>
            <div class="footer flex-align-center">
              <!--              <img src="">-->
              <div class="icon"></div>
              <div class="title">{{ item.title }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swiper from "swiper";

export default {
  name: "section-2",
  props:['loadedOver'],
  data() {
    return {
      swiper: null,
      list: [
        {
          title: "需求发布",
          tags: ["需求信息提报", "运营方审核通过", "定向发送", "智能推荐", "公开发布"]
        }, {
          title: "项目承接",
          tags: ["需求信息提报", "运营方审核通过", "定向发送", "智能推荐", "公开发布"]
        }, {
          title: "项目管理",
          tags: ["需求信息提报", "运营方审核通过", "定向发送", "智能推荐", "公开发布"]
        }, {
          title: "项目总结",
          tags: ["需求信息提报", "运营方审核通过", "定向发送", "智能推荐", "公开发布"]
        }, {
          title: "需求发布1",
          tags: ["需求信息提报", "运营方审核通过", "定向发送", "智能推荐", "公开发布"]
        }, {
          title: "项目总结",
          tags: ["需求信息提报", "运营方审核通过", "定向发送", "智能推荐", "公开发布"]
        }, {
          title: "需求发布",
          tags: ["需求信息提报", "运营方审核通过", "定向发送", "智能推荐", "公开发布"]
        }, {
          title: "需求发布",
          tags: ["需求信息提报", "运营方审核通过", "定向发送", "智能推荐", "公开发布"]
        }
      ]
    };
  },
  created() {
    this.getDetail()
  },
  mounted() {
    this.initSwiper();
  },
  methods: {
    emitLoadOver(){
      this.loadedOver('loadedOver','section2')
    },
    getDetail(){

    },
    initSwiper() {
      this.swiper = new Swiper(".swiper-container3", {
        // autoplay: true,//可选选项，自动滑动
        slidesPerView: 3.8,
        spaceBetween: 40
      });
    }
  }
};
</script>

<style lang="less" scoped>
@import "./common.less";

.container {
  width: 100%;
  height: calc(48px + 18px + 473px - 100px);
  margin-top: 70px;
  overflow-x: hidden;

  .content {
    //width: calc(1440px - 119px - 54px);
    //width: 100%;
    width: calc(317px + 1004px);
    height: 100%;
    margin-left: auto;
    margin-right: auto;
    //overflow: hidden;
    position: relative;

    .swiper-container3 {
      margin-top: 57px;
      position: absolute;
      left: 0px;
      bottom: 0px;

      .tarans {
        display: flex;
        padding-top: 30px;
        margin-left: 110px;

        .swiper-slide {
          background: @bg-white;
          border-radius: 4px 4px 4px 4px;
          background: #FFFFFF;
          box-shadow: 0px 2px 3px 0px rgba(49, 49, 49, 0.02), 0px 8px 7px 0px rgba(49, 49, 49, 0.04);
          opacity: 1;
          border: 1px solid #EDEDED;
          width: 317px !important;
          height: 299px !important;
          position: relative;
          padding-top: 38px;
          padding-left: 30px;

          .tag {
            display: inline-block;
            height: 32px;
            padding: 4px 8px;
            background: #F6F6FD;
            margin-bottom: 10px;
            border-radius: 4px 4px 4px 4px;
          }

          .number {
            position: absolute;
            top: -25px;
            left: 33px;
            width: 54px;
            height: 54px;
            background: #0D7CFF;
            border-radius: 50%;
            text-align: center;
            line-height: 54px;
            font-size: 40px;
            font-family: DIN-Bold, DIN;
            font-weight: bold;
            color: #FFFFFF;
          }

          .big-number {
            position: absolute;
            font-size: 200px;
            bottom: -70px;
            font-family: '微软雅黑 Arial';
            font-weight: bold;
            z-index: 555;
            right: 10px;
            color: #F3F3F8;
            opacity: 1;
          }

          .ivu-dividers {
            position: absolute;
            left: 0px;
            top: 242px;
            width: 316px;
            height: 0px;
            opacity: 1;
            border: 1px solid #EAEFF3;
          }

          .footer {
            .icon {
              margin-top: 4px;
              width: 36px;
              height: 36px;
              background: #5076F8;
              opacity: 1;
              border-radius: 50%;
            }

            .title {
              margin-left: 11px;
              font-size: 20px;
              font-family: PingFang SC-Bold, PingFang SC;
              font-weight: bold;
              color: #000000;
            }
          }
        }

        .item:first-child {
          margin-left: 127px;
        }
      }
    }
  }
}
</style>