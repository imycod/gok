<template>
  <div class="container" v-if="list.length">
    <div class="content">
      <div style="text-align: center"  v-scrollReveal>
        <div class="title">校企合作成果案例</div>
        <p class="sub">School-enterprise cooperation achievements case</p>
      </div>
      <i-carousel :list="list" ref="carousel"></i-carousel>
    </div>
  </div>
</template>

<script>
import carousel from "./section-1-carousel/index.vue"
import { achieveCase } from "@api/cooperation.js";

export default {
  name: "section-1",
  props:['loadedOver'],
  data(){
    return {
      list:[]
    }
  },
  created() {
    this.getDetail()
  },
  mounted() { },
  methods:{
    async getDetail(){
      const res = await achieveCase();
      if (res.status===200){
        this.list=res.data
        this.emitLoadOver()
        this.$nextTick(() => {
          this.$refs.carousel?.init();
        });
      }else{
        console.error('getDetail achieveCase resp get is error');
      }
    },
    emitLoadOver(){
      this.loadedOver('section1')
    }
  },
  components:{
    'i-carousel':carousel,
  }
};
</script>

<style lang="less" scoped>
@import "./common.less";
.container {
  width: 100%;
  height: calc(48px + 18px + 496px - 70px);
  margin-top: 51px;

  .content{
    //width: calc(1440px - 119px - 121px);
    width: calc(525px + 32px + 543px);
    height: 100%;
    margin-left: auto;
    margin-right: auto;

  }
}
</style>