<template>
  <div class="container">
    <div class="content bd">
      <div class="content bd">
        <div class="title">校企合作成果案例</div>
        <p class="sub">School-enterprise cooperation achievements case</p>



      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "section-1"
};
</script>

<style lang="less" scoped>
@import "./common.less";
.container {
  width: 100%;
  height: calc(48px + 18px + 496px - 70px);
  margin-top: 51px;

  .content{
    width: calc(1440px - 119px - 54px);
    height: 100%;
    margin-left: auto;
    margin-right: auto;

  }
}
</style>