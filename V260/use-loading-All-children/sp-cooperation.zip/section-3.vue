<template>
  <div class="container" v-if="isList">
    <div class="wrapper"></div>
    <div class="content">
      <div v-scrollReveal  style="text-align: center">
        <div class="title">校企需求对接类型</div>
        <p class="sub">School-enterprise cooperation achievements case</p>
      </div>
      <div class="item-wrapper">
        <div class="item" v-for="(item,index) in list" :key="index">
          <img class="icon" :src="item.url">
          <div class="title">{{ item.name }}</div>
          <div class="tags" v-if="item.items.length<=7">
            <Tag class="tag" v-for="(item,cindex) in item.items.slice(0,7)" :key="cindex">{{ item }}</Tag>
          </div>
          <div class="tags" v-else>
            <Tag class="tag" v-for="(item,cindex) in item.items.slice(0,7)" :key="cindex">{{ item }}</Tag>
            <Tag class="tag">...</Tag>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {needsAbutment} from "@api/cooperation.js"

export default {
  name: "section-3",
  props:['loadedOver'],
  data() {
    return {
      isList:false,
      list: [
        // {
        //   name: "数字化",
        //   url: require("@/assets/images/copr/need-1.png"),
        //   items: ["硬件开发", "运营方审核通过", "定向发送", "智能推荐", "大屏可视化"]
        // }, {
        //   name: "智能制造与工业设计",
        //   url: require("@/assets/images/copr/need-2.png"),
        //   items: ["需求信息提报", "嵌入式开发", "定向发送", "智能推荐", "公开发布", "定向发送", "智能推荐", "公开发布"]
        // }, {
        //   name: "人力资源服务",
        //   url: require("@/assets/images/copr/need-3.png"),
        //   items: ["需求信息提报", "人力资源服务", "定向发送", "智能推荐", "公开发布"]
        // }
      ]
    };
  },
  created() {
    this.getDetail()
  },
  methods:{
    emitLoadOver(){
      this.loadedOver('section3')
    },
    async getDetail(){
      const res = await needsAbutment();
      if (res.status===200){
        const list=[]
        this.isList=res.data.length ? true :false
        res.data.forEach((item,index)=>{
          list.push({...item,url:require(`@/assets/images/copr/need-${index+1}.png`)})
        })
        this.list =list
        this.emitLoadOver()
      }else{
        console.error('getDetail needsAbutment resp get is error');
      }
    }
  }
};
</script>

<style lang="less" scoped>
@import "./common.less";

.container {
  width: 100%;
  height: calc(48px + 18px + 544px - 113px);
  margin-top: 100px;

  position: relative;

  .wrapper {
    margin-top: 60px;
    //width: 1210px;
    width: 80%;
    height: 371px;
    background: #DAE8FE;
    border-radius: 50px 0px 0px 0px;
    position: absolute;
    bottom: 0px;
    right: 0px;
    z-index: -3;
  }
  .content {
    //width: calc(1440px - 119px - 54px);
    width: calc(372px * 3 + 41px + 50px);
    height: 100%;
    margin-left: auto;
    margin-right: auto;

    .item-wrapper {
      display: flex;
      margin-top: 136px;
      width: 100%;

      .item {
        margin-right: 41px;
        width: 372px;
        height: 218px;
        background: #FFFFFF;
        box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.01), 0px 8px 7px 0px rgba(0, 0, 0, 0.01), 0px 20px 13px 0px rgba(0, 0, 0, 0.01), 0px 39px 25px 0px rgba(0, 0, 0, 0.02), 0px 65px 47px 0px rgba(0, 0, 0, 0.02), 0px 100px 80px 0px rgba(0, 0, 0, 0.03);
        border-radius: 10px 10px 10px 10px;
        opacity: 1;
        padding-top: 32px;
        padding-left: 41px;
        padding-right: 45px;
        position: relative;
        .icon{
          width: 78px;
          height: 101px;
          position: absolute;
          z-index: 6;
          top: -80px;
          left: 50%;
          transform: translateX(-50%);
        }
        .title {
          font-size: 20px;
          font-family: PingFang SC-Heavy, PingFang SC;
          font-weight: 800;
          color: #000000;
          text-align: center;
        }
        .tags{
          margin-top: 16px;
          word-wrap:break-word;
          overflow: hidden;
          height: 120px;
          .tag{
            background: #F6F6FD !important;
            border-radius: 4px 4px 4px 4px;
            height: 32px;
            line-height: 32px;
            margin-right: 20px;
            margin-bottom: 10px;
            /deep/ .ivu-tag-text{
              font-size: 14px;
              font-family: PingFang SC-Medium, PingFang SC;
              font-weight: 500;
              color: #3734A9;
            }
            &:nth-last-child(1){
              margin-right: 0px;
            }
          }

        }
      }
      .item:last-child{
        margin-right: 0px;
      }
    }
  }
}
</style>