<template>
  <div class="container">
    <div v-show="!loading">
      <section-1 @loadedOver="loadedOver"></section-1>
      <!--    <section-2></section-2>-->
      <section-3 @loadedOver="loadedOver"></section-3>
      <section-4 @loadedOver="loadedOver"></section-4>
      <section-5 @loadedOver="loadedOver"></section-5>
    </div>
    <div>

    </div>
  </div>
</template>

<script>
import section1 from "@views/cooperation/sp-cooperation/section-1.vue";
import section2 from "@views/cooperation/sp-cooperation/section-2.vue";
import section3 from "@views/cooperation/sp-cooperation/section-3.vue";
import section4 from "@views/cooperation/sp-cooperation/section-4.vue";
import section5 from "@views/cooperation/sp-cooperation/section-5.vue";

export default {
  data(){
    return{
      loading:true,
      // 组件数据分别请求，有些快有些慢加载，会造成页面重排需要等全部加载完在让它一次性渲染
      componentsLoading:{
        section1: false,
        section3: false,
        section4: false,
        section5: false,
      }
    }
  },
  components: {
    "section-1": section1,
    // "section-2": section2,
    "section-3": section3,
    "section-4": section4,
    "section-5": section5,
  },
  methods:{
    loadedOver(componentName){
      this.componentsLoading[componentName] = true
      if (this.isLoadAllOver()) {
        // 计算高度
        this.loading = false
      }
    },
    isLoadAllOver() {
      const result = Object.keys(this.componentsLoading).every((key) => {
        return this.componentsLoading[key]
      })
      return result
    }
  }
};
</script>

<style lang="less" scoped>
.container {
  width: 100%;
  overflow-x: hidden;
  overflow-y: hidden;
}
</style>
