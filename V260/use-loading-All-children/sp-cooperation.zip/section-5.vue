<template>
  <div class="container" v-if="list.length">
    <div class="wrapper h-full">
      <div v-scrollReveal>
        <div class="page-title">校企合作 •优质供应商</div>
        <p class="sub">School-enterprise cooperation achievements case</p>
      </div>
      <div class="content w-full h-full">
        <div class="item" v-openHref="item.website" v-for="(item,index) in list" :key="index">
          <img class="img" :src="item.coverUrl" alt="">
          <div class="inner">
            <img class="avatar" :src="item.logoUrl" alt="">
            <div class="title">{{ item.name }}</div>
            <p class="sub">{{ item.remark }}</p>
            <div class="tags">
              <Tag class="tag" v-for="item in item.tags.slice(0,5)" :key="item.id">{{ item }}</Tag>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { companys, teams } from "@api/cooperation.js";
export default {
  name: "section-5",
  props:['loadedOver'],
  data() {
    return {
      list: [
        {
          name: "第四届“绽放杯”5G应用征集大赛福建区域赛圆满收官",
          remark: "第四届“绽放杯”5G应用征集大赛福建区域赛圆满收官第四届“绽放杯”5G应用征集大赛福建区域赛圆满收官绽放杯”5G应用征集大赛福建区域赛圆满收官绽放杯”5G应用征集大赛福建区域赛圆满收官",
          coverUrl: "https://gok-static.obs.cn-east-2.myhuaweicloud.com/portal/images/banner/product-detail.png",
          logoUrl: "https://gok-static.obs.cn-east-2.myhuaweicloud.com/portal/images/banner/product-detail.png",
          tags: ["硬件开发", "运营方审核通过", "定向发送", "智能推荐", "大屏可视化"]
        },
      ]
    };
  },
  created() {
    this.getDetail()
  },
  mounted() {
  },
  methods: {
    emitLoadOver(){
      this.loadedOver('section5')
    },
    async getDetail(){
      const res = await companys();
      if (res.status===200){
        this.list=res.data
        this.emitLoadOver()
        console.log('getDetail companys section-5',res.data);
      } else{
        console.error('getDetail companys resp get is error');
      }
    },
  }
};
</script>

<style lang="less" scoped>
.container {
  width: 100%;
  height: 1110px + 39px;
  background-color: #DAE8FE;
  background-image: url("~@/assets/images/copr/map.png");
  background-repeat: no-repeat;
  background-position-y: 60px;
  background-size: cover;

  .wrapper {
    width: calc(1440px - 116px - 123px);
    margin-left: auto;
    margin-right: auto;
    display: flex;
    align-items: center;
    flex-direction: column;

    .page-title {
      margin-top: 25px;
      font-size: 32px;
      font-family: Source Han Sans CN-Bold, Source Han Sans CN;
      font-weight: bold;
      color: #3734A9;
    }

    .sub {
      min-height:78px;
      .g-text-overflow(3);
      margin-top: 2px;
      font-size: 12px;
      font-family: Source Han Sans CN-Bold, Source Han Sans CN;
      font-weight: bold;
      color: #666666;
    }

    .content {
      margin-top: 48px;
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      .item {
        margin-right: 20px;
        box-sizing: border-box;
        width: 372px;
        height: calc(198px + 260px);
        .img {
          vertical-align: bottom;
          width: 372px;
          height: 198px;
          border-radius: 8px 8px 0px 0px;
        }

        .inner {
          padding: 17px 23px 3px 25px;
          box-sizing: border-box;
          position: relative;
          background: rgba(255,255,255,0.8);
          box-shadow: 4px 0px 20px 0px rgba(0,0,0,0.03);
          border-radius: 0px 0px 0px 0px;
          opacity: 1;
          border: 1px solid rgba(255,255,255,0.5);
          .avatar{
            width: 78px;
            height: 78px;
            border-radius: 50%;
            position: absolute;
            top: -50px;
            right: 15px;
          }
          .title {
            font-size: 20px;
            font-family: PingFang SC-Bold, PingFang SC;
            font-weight: bold;
            color: #000000;
            .g-text-overflow(2);
          }

          .sub {
            margin-top: 9px;
            font-size: 16px;
            font-family: PingFang SC-Medium, PingFang SC;
            font-weight: 500;
            color: #666666;
            .g-text-overflow(3);
          }

          .tags {
            margin-top: 10px;

            .tag {
              background: #ffffff !important;
              border-radius: 4px 4px 4px 4px;
              height: 32px;
              line-height: 32px;
              margin-right: 20px;
              margin-bottom: 14px;

              /deep/ .ivu-tag-text {
                font-size: 14px;
                font-family: PingFang SC-Medium, PingFang SC;
                font-weight: 500;
                color: #3734A9;
              }

              &:nth-last-child(1) {
                margin-right: 0px;
              }
            }
          }
        }
      }
    }
  }
}
</style>